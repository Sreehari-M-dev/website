import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import Header from "@/components/header";
import SearchFilters from "@/components/search-filters";
import FeaturedTip from "@/components/featured-tip";
import TipsList from "@/components/tips-list";
import Sidebar from "@/components/sidebar";
import ShareModal from "@/components/share-modal";
import { useLocalStorage } from "@/hooks/use-local-storage";
import type { Tip, UserStats, UserSettings } from "@shared/schema";

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [tipToShare, setTipToShare] = useState<Tip | null>(null);
  const [currentUserId] = useLocalStorage("userId", "demo-user");

  // Fetch tips based on filters
  const { data: tips = [], isLoading: tipsLoading } = useQuery({
    queryKey: ["/api/tips", { category: selectedCategory === "all" ? undefined : selectedCategory, search: searchQuery || undefined }],
  });

  // Fetch user stats
  const { data: userStats } = useQuery<UserStats>({
    queryKey: ["/api/user-stats", currentUserId],
  });

  // Fetch user settings
  const { data: userSettings } = useQuery<UserSettings>({
    queryKey: ["/api/user-settings", currentUserId],
  });

  // Fetch favorites
  const { data: favorites = [] } = useQuery({
    queryKey: ["/api/favorites", currentUserId],
  });

  // Toggle favorite mutation
  const toggleFavoriteMutation = useMutation({
    mutationFn: async ({ tipId, isFavorite }: { tipId: string; isFavorite: boolean }) => {
      if (isFavorite) {
        await apiRequest("DELETE", `/api/favorites/${currentUserId}/${tipId}`);
      } else {
        await apiRequest("POST", "/api/favorites", { userId: currentUserId, tipId });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/favorites", currentUserId] });
      queryClient.invalidateQueries({ queryKey: ["/api/user-stats", currentUserId] });
    },
  });

  // Update user stats mutation
  const updateStatsMutation = useMutation({
    mutationFn: async (updates: Partial<UserStats>) => {
      const response = await apiRequest("PATCH", `/api/user-stats/${currentUserId}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user-stats", currentUserId] });
    },
  });

  const handleCategoryFilter = (category: string) => {
    setSelectedCategory(category);
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const handleToggleFavorite = (tip: Tip) => {
    const isFavorite = favorites.some((fav: any) => fav.tipId === tip.id);
    toggleFavoriteMutation.mutate({ tipId: tip.id, isFavorite });
  };

  const handleShareTip = (tip: Tip) => {
    setTipToShare(tip);
    setShareModalOpen(true);
  };

  const handleMarkAsRead = (tip: Tip) => {
    if (userStats) {
      updateStatsMutation.mutate({
        tipsRead: userStats.tipsRead + 1,
        weeklyTipsRead: userStats.weeklyTipsRead + 1,
      });
    }
  };

  const featuredTip = tips[0];
  const moreTips = tips.slice(1, 4);

  const isTipFavorite = (tipId: string) => {
    return favorites.some((fav: any) => fav.tipId === tipId);
  };

  return (
    <div className="min-h-screen p-4 lg:p-6">
      <Header userStats={userStats} />
      
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <SearchFilters
            selectedCategory={selectedCategory}
            onCategoryFilter={handleCategoryFilter}
            onSearch={handleSearch}
          />

          {featuredTip && (
            <FeaturedTip
              tip={featuredTip}
              isFavorite={isTipFavorite(featuredTip.id)}
              onToggleFavorite={() => handleToggleFavorite(featuredTip)}
              onShare={() => handleShareTip(featuredTip)}
              onMarkAsRead={() => handleMarkAsRead(featuredTip)}
            />
          )}

          <TipsList
            tips={moreTips}
            onToggleFavorite={handleToggleFavorite}
            onShare={handleShareTip}
            isTipFavorite={isTipFavorite}
            isLoading={tipsLoading}
          />
        </div>

        <Sidebar
          userStats={userStats}
          favorites={favorites.slice(0, 3)}
          userSettings={userSettings}
          currentUserId={currentUserId}
        />
      </div>

      <ShareModal
        isOpen={shareModalOpen}
        onClose={() => setShareModalOpen(false)}
        tip={tipToShare}
      />
    </div>
  );
}
