import { z } from "zod";

// Basic types for tips
export const tipSchema = z.object({
  id: z.string(),
  title: z.string(),
  content: z.string(),
  category: z.string(),
  readTime: z.string(),
  createdAt: z.date().optional(),
});

export const insertTipSchema = tipSchema.omit({
  id: true,
  createdAt: true,
});

// User types
export const userStatsSchema = z.object({
  id: z.string(),
  userId: z.string(),
  tipsRead: z.number().default(0),
  favorites: z.number().default(0),
  streak: z.number().default(0),
  weeklyTipsRead: z.number().default(0),
  weeklyChallenges: z.number().default(0),
});

export const insertUserStatsSchema = userStatsSchema.omit({
  id: true,
});

// Favorites types
export const userFavoriteSchema = z.object({
  id: z.string(),
  userId: z.string(),
  tipId: z.string(),
  createdAt: z.date().optional(),
});

export const insertUserFavoriteSchema = userFavoriteSchema.omit({
  id: true,
  createdAt: true,
});

// Settings types
export const userSettingsSchema = z.object({
  id: z.string(),
  userId: z.string(),
  notifications: z.boolean().default(true),
  autoMarkRead: z.boolean().default(false),
});

export const insertUserSettingsSchema = userSettingsSchema.omit({
  id: true,
});

export type Tip = z.infer<typeof tipSchema>;
export type InsertTip = z.infer<typeof insertTipSchema>;
export type UserStats = z.infer<typeof userStatsSchema>;
export type InsertUserStats = z.infer<typeof insertUserStatsSchema>;
export type UserFavorite = z.infer<typeof userFavoriteSchema>;
export type InsertUserFavorite = z.infer<typeof insertUserFavoriteSchema>;
export type UserSettings = z.infer<typeof userSettingsSchema>;
export type InsertUserSettings = z.infer<typeof insertUserSettingsSchema>;