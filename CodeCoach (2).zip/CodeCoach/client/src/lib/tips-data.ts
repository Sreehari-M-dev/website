export const CATEGORIES = [
  { id: "focus", name: "Focus", icon: "fas fa-bullseye" },
  { id: "wellness", name: "Wellness", icon: "fas fa-heart" },
  { id: "time", name: "Time Management", icon: "fas fa-clock" },
  { id: "organization", name: "Organization", icon: "fas fa-sitemap" },
  { id: "motivation", name: "Motivation", icon: "fas fa-rocket" },
];

export const getCategoryById = (id: string) => {
  return CATEGORIES.find(cat => cat.id === id);
};

export const getCategoryIcon = (category: string) => {
  const categoryObj = getCategoryById(category);
  return categoryObj?.icon || "fas fa-lightbulb";
};
