import { 
  type Tip, 
  type InsertTip,
  type UserStats,
  type InsertUserStats,
  type UserFavorite,
  type InsertUserFavorite,
  type UserSettings,
  type InsertUserSettings
} from "./schema";

export interface IStorage {
  getTips(): Promise<Tip[]>;
  getTip(id: string): Promise<Tip | undefined>;
  createTip(tip: InsertTip): Promise<Tip>;
  getTipsByCategory(category: string): Promise<Tip[]>;
  searchTips(query: string): Promise<Tip[]>;
  
  getUserStats(userId: string): Promise<UserStats | undefined>;
  createUserStats(stats: InsertUserStats): Promise<UserStats>;
  updateUserStats(userId: string, stats: Partial<UserStats>): Promise<UserStats | undefined>;
  
  getUserFavorites(userId: string): Promise<UserFavorite[]>;
  addFavorite(favorite: InsertUserFavorite): Promise<UserFavorite>;
  removeFavorite(userId: string, tipId: string): Promise<boolean>;
  isFavorite(userId: string, tipId: string): Promise<boolean>;
  
  getUserSettings(userId: string): Promise<UserSettings | undefined>;
  createUserSettings(settings: InsertUserSettings): Promise<UserSettings>;
  updateUserSettings(userId: string, settings: Partial<UserSettings>): Promise<UserSettings | undefined>;
}

function generateId(): string {
  return Math.random().toString(36).substr(2, 9);
}

export class MemStorage implements IStorage {
  private tips: Map<string, Tip>;
  private userStats: Map<string, UserStats>;
  private userFavorites: Map<string, UserFavorite>;
  private userSettings: Map<string, UserSettings>;

  constructor() {
    this.tips = new Map();
    this.userStats = new Map();
    this.userFavorites = new Map();
    this.userSettings = new Map();
    
    this.initializeTips();
  }

  private initializeTips() {
    const initialTips: InsertTip[] = [
      {
        title: "The Two-Minute Rule",
        content: "If a task takes less than two minutes, do it immediately rather than adding it to your to-do list. This simple rule prevents small tasks from accumulating and becoming overwhelming.",
        category: "focus",
        readTime: "2 min read"
      },
      {
        title: "Take Regular Movement Breaks",
        content: "Stand up and move for 2-3 minutes every hour to boost circulation and mental clarity. Set a timer to remind yourself to step away from your desk.",
        category: "wellness",
        readTime: "3 min read"
      },
      {
        title: "Time Blocking Method",
        content: "Allocate specific time slots for different activities to protect your schedule and maintain focus. This prevents tasks from expanding beyond their intended duration.",
        category: "time",
        readTime: "4 min read"
      },
      {
        title: "Digital Declutter",
        content: "Organize your digital workspace by cleaning up desktop files and organizing folders systematically. A clean digital environment leads to clearer thinking.",
        category: "organization",
        readTime: "2 min read"
      },
      {
        title: "Start with Your Hardest Task",
        content: "Tackle your most challenging task first when your energy levels are highest. This approach, known as 'eating the frog', builds momentum for the rest of your day.",
        category: "motivation",
        readTime: "3 min read"
      },
      {
        title: "Use the Pomodoro Technique",
        content: "Work for 25 minutes, then take a 5-minute break to maintain focus and prevent burnout. This technique helps maintain consistent productivity throughout the day.",
        category: "focus",
        readTime: "4 min read"
      },
      {
        title: "Practice Deep Breathing",
        content: "Take 5 deep breaths when feeling overwhelmed. This simple technique activates your parasympathetic nervous system and helps restore mental clarity.",
        category: "wellness",
        readTime: "2 min read"
      },
      {
        title: "Batch Similar Tasks",
        content: "Group similar activities together to reduce context switching and maintain momentum. For example, batch all your email responses or phone calls.",
        category: "time",
        readTime: "3 min read"
      },
      {
        title: "Create Daily Templates",
        content: "Develop templates for recurring tasks to save time and ensure consistency. This reduces decision fatigue and speeds up routine processes.",
        category: "organization",
        readTime: "3 min read"
      },
      {
        title: "Celebrate Small Wins",
        content: "Acknowledge and celebrate your daily accomplishments, no matter how small. This builds positive momentum and maintains motivation over time.",
        category: "motivation",
        readTime: "2 min read"
      }
    ];

    initialTips.forEach(tip => {
      const id = generateId();
      const fullTip: Tip = { 
        ...tip, 
        id, 
        createdAt: new Date() 
      };
      this.tips.set(id, fullTip);
    });
  }

  async getTips(): Promise<Tip[]> {
    return Array.from(this.tips.values());
  }

  async getTip(id: string): Promise<Tip | undefined> {
    return this.tips.get(id);
  }

  async createTip(insertTip: InsertTip): Promise<Tip> {
    const id = generateId();
    const tip: Tip = { 
      ...insertTip, 
      id, 
      createdAt: new Date() 
    };
    this.tips.set(id, tip);
    return tip;
  }

  async getTipsByCategory(category: string): Promise<Tip[]> {
    return Array.from(this.tips.values()).filter(tip => tip.category === category);
  }

  async searchTips(query: string): Promise<Tip[]> {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.tips.values()).filter(tip => 
      tip.title.toLowerCase().includes(lowercaseQuery) ||
      tip.content.toLowerCase().includes(lowercaseQuery) ||
      tip.category.toLowerCase().includes(lowercaseQuery)
    );
  }

  async getUserStats(userId: string): Promise<UserStats | undefined> {
    return Array.from(this.userStats.values()).find(stats => stats.userId === userId);
  }

  async createUserStats(insertStats: InsertUserStats): Promise<UserStats> {
    const id = generateId();
    const stats: UserStats = { ...insertStats, id };
    this.userStats.set(id, stats);
    return stats;
  }

  async updateUserStats(userId: string, updates: Partial<UserStats>): Promise<UserStats | undefined> {
    const existingStats = Array.from(this.userStats.values()).find(stats => stats.userId === userId);
    if (!existingStats) return undefined;
    
    const updatedStats = { ...existingStats, ...updates };
    this.userStats.set(existingStats.id, updatedStats);
    return updatedStats;
  }

  async getUserFavorites(userId: string): Promise<UserFavorite[]> {
    return Array.from(this.userFavorites.values()).filter(fav => fav.userId === userId);
  }

  async addFavorite(insertFavorite: InsertUserFavorite): Promise<UserFavorite> {
    const id = generateId();
    const favorite: UserFavorite = { 
      ...insertFavorite, 
      id, 
      createdAt: new Date() 
    };
    this.userFavorites.set(id, favorite);
    return favorite;
  }

  async removeFavorite(userId: string, tipId: string): Promise<boolean> {
    const favorite = Array.from(this.userFavorites.values()).find(
      fav => fav.userId === userId && fav.tipId === tipId
    );
    if (!favorite) return false;
    
    this.userFavorites.delete(favorite.id);
    return true;
  }

  async isFavorite(userId: string, tipId: string): Promise<boolean> {
    return Array.from(this.userFavorites.values()).some(
      fav => fav.userId === userId && fav.tipId === tipId
    );
  }

  async getUserSettings(userId: string): Promise<UserSettings | undefined> {
    return Array.from(this.userSettings.values()).find(settings => settings.userId === userId);
  }

  async createUserSettings(insertSettings: InsertUserSettings): Promise<UserSettings> {
    const id = generateId();
    const settings: UserSettings = { ...insertSettings, id };
    this.userSettings.set(id, settings);
    return settings;
  }

  async updateUserSettings(userId: string, updates: Partial<UserSettings>): Promise<UserSettings | undefined> {
    const existingSettings = Array.from(this.userSettings.values()).find(settings => settings.userId === userId);
    if (!existingSettings) return undefined;
    
    const updatedSettings = { ...existingSettings, ...updates };
    this.userSettings.set(existingSettings.id, updatedSettings);
    return updatedSettings;
  }
}

export const storage = new MemStorage();