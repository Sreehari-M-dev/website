import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import type { Tip } from "@shared/schema";

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  tip: Tip | null;
}

export default function ShareModal({ isOpen, onClose, tip }: ShareModalProps) {
  const { toast } = useToast();

  if (!tip) return null;

  const shareUrl = `${window.location.origin}/?tip=${tip.id}`;
  const shareText = `Check out this productivity tip: "${tip.title}" - ${tip.content.substring(0, 100)}...`;

  const handleShareTwitter = () => {
    const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`;
    window.open(twitterUrl, '_blank');
  };

  const handleShareLinkedIn = () => {
    const linkedInUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`;
    window.open(linkedInUrl, '_blank');
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      toast({
        title: "Link Copied",
        description: "The tip link has been copied to your clipboard.",
      });
      onClose();
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to copy link to clipboard.",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="glass-effect-dark border-none shadow-2xl animate-slideUp max-w-md">
        <DialogHeader>
          <DialogTitle className="text-lg font-bold text-gray-800">Share Tip</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <Button
            onClick={handleShareTwitter}
            className="w-full flex items-center gap-3 p-3 bg-blue-500/10 hover:bg-blue-500/20 text-gray-700 justify-start"
            variant="outline"
          >
            <i className="fab fa-twitter text-blue-500"></i>
            <span>Share on Twitter</span>
          </Button>
          <Button
            onClick={handleShareLinkedIn}
            className="w-full flex items-center gap-3 p-3 bg-blue-600/10 hover:bg-blue-600/20 text-gray-700 justify-start"
            variant="outline"
          >
            <i className="fab fa-linkedin text-blue-600"></i>
            <span>Share on LinkedIn</span>
          </Button>
          <Button
            onClick={handleCopyLink}
            className="w-full flex items-center gap-3 p-3 bg-gray-500/10 hover:bg-gray-500/20 text-gray-700 justify-start"
            variant="outline"
          >
            <i className="fas fa-link text-gray-500"></i>
            <span>Copy Link</span>
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
