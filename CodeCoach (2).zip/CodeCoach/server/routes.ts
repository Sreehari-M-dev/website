import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTipSchema, insertUserStatsSchema, insertUserFavoriteSchema, insertUserSettingsSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Tips routes
  app.get("/api/tips", async (req, res) => {
    try {
      const { category, search } = req.query;
      
      let tips;
      if (search) {
        tips = await storage.searchTips(search as string);
      } else if (category) {
        tips = await storage.getTipsByCategory(category as string);
      } else {
        tips = await storage.getTips();
      }
      
      res.json(tips);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tips" });
    }
  });

  app.get("/api/tips/:id", async (req, res) => {
    try {
      const tip = await storage.getTip(req.params.id);
      if (!tip) {
        return res.status(404).json({ message: "Tip not found" });
      }
      res.json(tip);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tip" });
    }
  });

  // User stats routes
  app.get("/api/user-stats/:userId", async (req, res) => {
    try {
      let stats = await storage.getUserStats(req.params.userId);
      if (!stats) {
        // Create default stats for new user
        stats = await storage.createUserStats({
          userId: req.params.userId,
          tipsRead: 47,
          favorites: 12,
          streak: 5,
          weeklyTipsRead: 12,
          weeklyChallenges: 3,
        });
      }
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user stats" });
    }
  });

  app.patch("/api/user-stats/:userId", async (req, res) => {
    try {
      const result = insertUserStatsSchema.partial().safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: "Invalid data", errors: result.error.errors });
      }

      const stats = await storage.updateUserStats(req.params.userId, result.data);
      if (!stats) {
        return res.status(404).json({ message: "User stats not found" });
      }
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to update user stats" });
    }
  });

  // Favorites routes
  app.get("/api/favorites/:userId", async (req, res) => {
    try {
      const favorites = await storage.getUserFavorites(req.params.userId);
      
      // Get tip details for each favorite
      const favoritesWithTips = await Promise.all(
        favorites.map(async (favorite) => {
          const tip = await storage.getTip(favorite.tipId);
          return { ...favorite, tip };
        })
      );
      
      res.json(favoritesWithTips);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch favorites" });
    }
  });

  app.post("/api/favorites", async (req, res) => {
    try {
      const result = insertUserFavoriteSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: "Invalid data", errors: result.error.errors });
      }

      // Check if already favorited
      const isAlreadyFavorite = await storage.isFavorite(result.data.userId, result.data.tipId);
      if (isAlreadyFavorite) {
        return res.status(400).json({ message: "Tip already favorited" });
      }

      const favorite = await storage.addFavorite(result.data);
      res.status(201).json(favorite);
    } catch (error) {
      res.status(500).json({ message: "Failed to add favorite" });
    }
  });

  app.delete("/api/favorites/:userId/:tipId", async (req, res) => {
    try {
      const removed = await storage.removeFavorite(req.params.userId, req.params.tipId);
      if (!removed) {
        return res.status(404).json({ message: "Favorite not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to remove favorite" });
    }
  });

  app.get("/api/favorites/:userId/:tipId/check", async (req, res) => {
    try {
      const isFavorite = await storage.isFavorite(req.params.userId, req.params.tipId);
      res.json({ isFavorite });
    } catch (error) {
      res.status(500).json({ message: "Failed to check favorite status" });
    }
  });

  // User settings routes
  app.get("/api/user-settings/:userId", async (req, res) => {
    try {
      let settings = await storage.getUserSettings(req.params.userId);
      if (!settings) {
        // Create default settings for new user
        settings = await storage.createUserSettings({
          userId: req.params.userId,
          notifications: true,
          autoMarkRead: false,
        });
      }
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user settings" });
    }
  });

  app.patch("/api/user-settings/:userId", async (req, res) => {
    try {
      const result = insertUserSettingsSchema.partial().safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: "Invalid data", errors: result.error.errors });
      }

      const settings = await storage.updateUserSettings(req.params.userId, result.data);
      if (!settings) {
        return res.status(404).json({ message: "User settings not found" });
      }
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to update user settings" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
