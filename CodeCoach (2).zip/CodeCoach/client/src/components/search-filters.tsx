import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface SearchFiltersProps {
  selectedCategory: string;
  onCategoryFilter: (category: string) => void;
  onSearch: (query: string) => void;
}

const categories = [
  { id: "all", name: "All", icon: "fas fa-grid-2", className: "" },
  { id: "focus", name: "Focus", icon: "fas fa-bullseye", className: "category-focus" },
  { id: "wellness", name: "Wellness", icon: "fas fa-heart", className: "category-wellness" },
  { id: "time", name: "Time Management", icon: "fas fa-clock", className: "category-time" },
  { id: "organization", name: "Organization", icon: "fas fa-sitemap", className: "category-organization" },
  { id: "motivation", name: "Motivation", icon: "fas fa-rocket", className: "category-motivation" },
];

export default function SearchFilters({ selectedCategory, onCategoryFilter, onSearch }: SearchFiltersProps) {
  const [searchValue, setSearchValue] = useState("");

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchValue(e.target.value);
    onSearch(e.target.value);
  };

  return (
    <div className="glass-effect rounded-2xl p-6 shadow-xl">
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1 relative">
          <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
          <Input
            type="text"
            placeholder="Search tips..."
            value={searchValue}
            onChange={handleSearchChange}
            className="pl-10 bg-white/70 border-gray-200 focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <Button className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700">
          <i className="fas fa-filter mr-2"></i>
          Filters
        </Button>
      </div>
      
      <div className="flex flex-wrap gap-2 mt-4">
        {categories.map((category) => (
          <Button
            key={category.id}
            variant="outline"
            size="sm"
            onClick={() => onCategoryFilter(category.id)}
            className={`
              px-3 py-1 rounded-full text-sm font-medium transition-colors
              ${selectedCategory === category.id ? 'ring-2 ring-offset-2' : ''}
              ${category.className || 'bg-gray-100/50 hover:bg-gray-200/50'}
            `}
          >
            <i className={`${category.icon} mr-1`}></i>
            {category.name}
          </Button>
        ))}
      </div>
    </div>
  );
}
