import { Button } from "@/components/ui/button";
import type { Tip } from "@shared/schema";

interface FeaturedTipProps {
  tip: Tip;
  isFavorite: boolean;
  onToggleFavorite: () => void;
  onShare: () => void;
  onMarkAsRead: () => void;
}

const getCategoryIcon = (category: string) => {
  const icons: Record<string, string> = {
    focus: "fas fa-bullseye",
    wellness: "fas fa-heart",
    time: "fas fa-clock",
    organization: "fas fa-sitemap",
    motivation: "fas fa-rocket",
  };
  return icons[category] || "fas fa-lightbulb";
};

const getCategoryClass = (category: string) => {
  const classes: Record<string, string> = {
    focus: "category-focus",
    wellness: "category-wellness",
    time: "category-time",
    organization: "category-organization",
    motivation: "category-motivation",
  };
  return classes[category] || "bg-gray-100/50";
};

export default function FeaturedTip({ tip, isFavorite, onToggleFavorite, onShare, onMarkAsRead }: FeaturedTipProps) {
  return (
    <div className="glass-effect-dark rounded-2xl p-8 shadow-2xl relative overflow-hidden animate-fadeIn">
      <div className="absolute top-4 right-4 flex gap-2">
        <Button
          variant="ghost"
          size="icon"
          onClick={onToggleFavorite}
          className="w-10 h-10 bg-white/20 hover:bg-white/30 rounded-full"
          title="Add to favorites"
        >
          <i className={`${isFavorite ? 'fas' : 'far'} fa-heart ${isFavorite ? 'text-red-500' : 'text-gray-600'}`}></i>
        </Button>
        <Button
          variant="ghost"
          size="icon"
          onClick={onShare}
          className="w-10 h-10 bg-white/20 hover:bg-white/30 rounded-full"
          title="Share tip"
        >
          <i className="fas fa-share text-gray-600"></i>
        </Button>
      </div>
      
      <div className="mb-4">
        <span className={`px-3 py-1 border rounded-full text-sm font-medium ${getCategoryClass(tip.category)}`}>
          <i className={`${getCategoryIcon(tip.category)} mr-1`}></i>
          {tip.category.charAt(0).toUpperCase() + tip.category.slice(1)}
        </span>
      </div>
      
      <div className="mb-6">
        <h2 className="text-2xl lg:text-3xl font-bold text-gray-800 mb-4 leading-relaxed">
          {tip.title}
        </h2>
        <p className="text-lg text-gray-700 leading-relaxed">
          {tip.content}
        </p>
      </div>
      
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button
            onClick={onMarkAsRead}
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
          >
            <i className="fas fa-check mr-2"></i>
            Mark as Read
          </Button>
        </div>
        <div className="text-sm text-gray-500">
          <i className="fas fa-clock mr-1"></i>
          {tip.readTime}
        </div>
      </div>
    </div>
  );
}
