import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { UserStats, UserSettings } from "@shared/schema";

interface SidebarProps {
  userStats?: UserStats;
  favorites: any[];
  userSettings?: UserSettings;
  currentUserId: string;
}

export default function Sidebar({ userStats, favorites, userSettings, currentUserId }: SidebarProps) {
  const { toast } = useToast();

  const updateSettingsMutation = useMutation({
    mutationFn: async (updates: Partial<UserSettings>) => {
      const response = await apiRequest("PATCH", `/api/user-settings/${currentUserId}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user-settings", currentUserId] });
    },
  });

  const handleSettingChange = (setting: keyof UserSettings, value: boolean) => {
    updateSettingsMutation.mutate({ [setting]: value });
  };

  const handleExportData = () => {
    const data = {
      userStats,
      favorites,
      userSettings,
      exportDate: new Date().toISOString(),
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'productivity-hub-data.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      title: "Data Exported",
      description: "Your productivity data has been downloaded successfully.",
    });
  };

  return (
    <div className="space-y-6">
      {/* Daily Challenge */}
      <div className="glass-effect rounded-2xl p-6 shadow-xl">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-lg flex items-center justify-center">
            <i className="fas fa-trophy text-yellow-800"></i>
          </div>
          <h3 className="text-lg font-bold text-gray-800">Daily Challenge</h3>
        </div>
        <p className="text-gray-600 mb-4">Try the Pomodoro Technique for your next work session</p>
        <div className="flex items-center justify-between">
          <Button className="bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-yellow-900">
            Accept Challenge
          </Button>
          <span className="text-xs text-gray-500">4h left</span>
        </div>
      </div>

      {/* Weekly Progress */}
      <div className="glass-effect rounded-2xl p-6 shadow-xl">
        <h3 className="text-lg font-bold text-gray-800 mb-4">This Week</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Tips Read</span>
            <span className="font-semibold text-gray-800">
              {userStats?.weeklyTipsRead || 0}/15
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-blue-500 to-purple-600 h-2 rounded-full transition-all duration-500" 
              style={{ width: `${Math.min(((userStats?.weeklyTipsRead || 0) / 15) * 100, 100)}%` }}
            ></div>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Challenges</span>
            <span className="font-semibold text-gray-800">
              {userStats?.weeklyChallenges || 0}/5
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-green-400 to-teal-500 h-2 rounded-full transition-all duration-500" 
              style={{ width: `${Math.min(((userStats?.weeklyChallenges || 0) / 5) * 100, 100)}%` }}
            ></div>
          </div>
        </div>
      </div>

      {/* Favorites */}
      <div className="glass-effect rounded-2xl p-6 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-gray-800">Favorites</h3>
          <Button variant="ghost" className="text-blue-500 hover:text-blue-600 text-sm font-medium">
            View All
          </Button>
        </div>
        <div className="space-y-3">
          {favorites.length > 0 ? (
            favorites.map((favorite) => (
              <div key={favorite.id} className="p-3 bg-white/50 rounded-lg hover:bg-white/70 transition-colors cursor-pointer">
                <div className="flex items-start gap-2">
                  <i className="fas fa-heart text-red-500 mt-1 text-sm"></i>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-800">{favorite.tip?.title || 'Unknown Tip'}</p>
                    <p className="text-xs text-gray-600">
                      {favorite.tip?.category ? `${favorite.tip.category.charAt(0).toUpperCase() + favorite.tip.category.slice(1)} • ` : ''}
                      {new Date(favorite.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <p className="text-gray-500 text-sm text-center py-4">No favorites yet</p>
          )}
        </div>
      </div>

      {/* Settings */}
      <div className="glass-effect rounded-2xl p-6 shadow-xl">
        <h3 className="text-lg font-bold text-gray-800 mb-4">Settings</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Daily Notifications</span>
            <Switch
              checked={userSettings?.notifications || false}
              onCheckedChange={(checked) => handleSettingChange('notifications', checked)}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Auto-mark as Read</span>
            <Switch
              checked={userSettings?.autoMarkRead || false}
              onCheckedChange={(checked) => handleSettingChange('autoMarkRead', checked)}
            />
          </div>
          
          <Button
            variant="outline"
            onClick={handleExportData}
            className="w-full bg-white/50 hover:bg-white/70 text-gray-700 text-sm"
          >
            <i className="fas fa-download mr-2"></i>
            Export My Data
          </Button>
        </div>
      </div>
    </div>
  );
}
