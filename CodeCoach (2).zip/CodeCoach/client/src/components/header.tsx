import type { UserStats } from "@shared/schema";

interface HeaderProps {
  userStats?: UserStats;
}

export default function Header({ userStats }: HeaderProps) {
  return (
    <header className="max-w-7xl mx-auto mb-8">
      <div className="glass-effect rounded-2xl p-6 shadow-xl">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl flex items-center justify-center text-white text-xl">
              <i className="fas fa-brain"></i>
            </div>
            <div>
              <h1 className="text-2xl lg:text-3xl font-bold text-gray-800">Productivity Hub</h1>
              <p className="text-gray-600 text-sm">Your daily dose of productivity wisdom</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-center">
              <div className="text-xl font-bold text-gray-800">{userStats?.tipsRead || 0}</div>
              <div className="text-xs text-gray-600">Tips Read</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold text-gray-800">{userStats?.favorites || 0}</div>
              <div className="text-xs text-gray-600">Favorites</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold text-gray-800">{userStats?.streak || 0}</div>
              <div className="text-xs text-gray-600">Day Streak</div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
