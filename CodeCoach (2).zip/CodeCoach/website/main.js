// Simple vanilla JavaScript productivity tips app

// Application state
let currentTips = [];
let allTips = [];
let currentUserId = 'demo-user';
let userStats = {};
let userFavorites = [];
let userSettings = {};

// Sample data since we don't have a backend in this standalone version
const sampleTips = [
  {
    id: '1',
    title: 'The Two-Minute Rule',
    content: 'If a task takes less than two minutes, do it immediately rather than adding it to your to-do list. This simple rule prevents small tasks from accumulating and becoming overwhelming.',
    category: 'focus',
    readTime: '2 min read'
  },
  {
    id: '2',
    title: 'Take Regular Movement Breaks',
    content: 'Stand up and move for 2-3 minutes every hour to boost circulation and mental clarity. Set a timer to remind yourself to step away from your desk.',
    category: 'wellness',
    readTime: '3 min read'
  },
  {
    id: '3',
    title: 'Time Blocking Method',
    content: 'Allocate specific time slots for different activities to protect your schedule and maintain focus. This prevents tasks from expanding beyond their intended duration.',
    category: 'time',
    readTime: '4 min read'
  },
  {
    id: '4',
    title: 'Digital Declutter',
    content: 'Organize your digital workspace by cleaning up desktop files and organizing folders systematically. A clean digital environment leads to clearer thinking.',
    category: 'organization',
    readTime: '2 min read'
  },
  {
    id: '5',
    title: 'Start with Your Hardest Task',
    content: 'Tackle your most challenging task first when your energy levels are highest. This approach, known as "eating the frog", builds momentum for the rest of your day.',
    category: 'motivation',
    readTime: '3 min read'
  },
  {
    id: '6',
    title: 'Use the Pomodoro Technique',
    content: 'Work for 25 minutes, then take a 5-minute break to maintain focus and prevent burnout. This technique helps maintain consistent productivity throughout the day.',
    category: 'focus',
    readTime: '4 min read'
  },
  {
    id: '7',
    title: 'Practice Deep Breathing',
    content: 'Take 5 deep breaths when feeling overwhelmed. This simple technique activates your parasympathetic nervous system and helps restore mental clarity.',
    category: 'wellness',
    readTime: '2 min read'
  },
  {
    id: '8',
    title: 'Batch Similar Tasks',
    content: 'Group similar activities together to reduce context switching and maintain momentum. For example, batch all your email responses or phone calls.',
    category: 'time',
    readTime: '3 min read'
  },
  {
    id: '9',
    title: 'Create Daily Templates',
    content: 'Develop templates for recurring tasks to save time and ensure consistency. This reduces decision fatigue and speeds up routine processes.',
    category: 'organization',
    readTime: '3 min read'
  },
  {
    id: '10',
    title: 'Celebrate Small Wins',
    content: 'Acknowledge and celebrate your daily accomplishments, no matter how small. This builds positive momentum and maintains motivation over time.',
    category: 'motivation',
    readTime: '2 min read'
  }
];

// Categories configuration
const categories = [
  { id: 'all', name: 'All', icon: 'fas fa-grid-2' },
  { id: 'focus', name: 'Focus', icon: 'fas fa-bullseye' },
  { id: 'wellness', name: 'Wellness', icon: 'fas fa-heart' },
  { id: 'time', name: 'Time Management', icon: 'fas fa-clock' },
  { id: 'organization', name: 'Organization', icon: 'fas fa-sitemap' },
  { id: 'motivation', name: 'Motivation', icon: 'fas fa-rocket' }
];

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
  initializeApp();
});

function initializeApp() {
  // Load data from localStorage or use defaults
  loadUserData();
  allTips = [...sampleTips];
  currentTips = [...allTips];
  
  // Render the application
  renderApp();
  
  // Set up event listeners
  setupEventListeners();
}

function loadUserData() {
  userStats = JSON.parse(localStorage.getItem('userStats')) || {
    tipsRead: 47,
    favorites: 12,
    streak: 5,
    weeklyTipsRead: 12,
    weeklyChallenges: 3
  };
  
  userFavorites = JSON.parse(localStorage.getItem('userFavorites')) || [];
  
  userSettings = JSON.parse(localStorage.getItem('userSettings')) || {
    notifications: true,
    autoMarkRead: false
  };
}

function saveUserData() {
  localStorage.setItem('userStats', JSON.stringify(userStats));
  localStorage.setItem('userFavorites', JSON.stringify(userFavorites));
  localStorage.setItem('userSettings', JSON.stringify(userSettings));
}

function renderApp() {
  const root = document.getElementById('root');
  root.innerHTML = `
    <div class="container">
      ${renderHeader()}
      <div class="grid grid-cols-1 lg:grid-cols-3">
        <div class="lg:col-span-2 space-y-6">
          ${renderSearchFilters()}
          ${renderFeaturedTip()}
          ${renderTipsList()}
        </div>
        <div class="space-y-6">
          ${renderSidebar()}
        </div>
      </div>
    </div>
    ${renderShareModal()}
  `;
}

function renderHeader() {
  return `
    <header class="mb-8">
      <div class="glass-effect rounded-2xl p-6 shadow-xl">
        <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div class="flex items-center gap-3">
            <div class="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl flex items-center justify-center text-white text-xl">
              <i class="fas fa-brain"></i>
            </div>
            <div>
              <h1 class="text-2xl lg:text-3xl font-bold text-gray-800">Productivity Hub</h1>
              <p class="text-gray-600 text-sm">Your daily dose of productivity wisdom</p>
            </div>
          </div>
          
          <div class="flex items-center gap-4">
            <div class="text-center">
              <div class="text-xl font-bold text-gray-800">${userStats.tipsRead}</div>
              <div class="text-xs text-gray-600">Tips Read</div>
            </div>
            <div class="text-center">
              <div class="text-xl font-bold text-gray-800">${userStats.favorites}</div>
              <div class="text-xs text-gray-600">Favorites</div>
            </div>
            <div class="text-center">
              <div class="text-xl font-bold text-gray-800">${userStats.streak}</div>
              <div class="text-xs text-gray-600">Day Streak</div>
            </div>
          </div>
        </div>
      </div>
    </header>
  `;
}

function renderSearchFilters() {
  return `
    <div class="glass-effect rounded-2xl p-6 shadow-xl">
      <div class="flex flex-col sm:flex-row gap-4">
        <div class="flex-1 relative">
          <i class="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
          <input
            type="text"
            placeholder="Search tips..."
            id="searchInput"
            class="input pl-10 bg-white/70 border-gray-200 focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <button class="btn btn-primary">
          <i class="fas fa-filter mr-2"></i>
          Filters
        </button>
      </div>
      
      <div class="flex flex-wrap gap-2 mt-4">
        ${categories.map(category => `
          <button
            class="btn btn-outline category-btn px-3 py-1 rounded-full text-sm font-medium transition-colors ${getCategoryClass(category.id)}"
            data-category="${category.id}"
          >
            <i class="${category.icon} mr-1"></i>
            ${category.name}
          </button>
        `).join('')}
      </div>
    </div>
  `;
}

function renderFeaturedTip() {
  if (currentTips.length === 0) return '';
  
  const tip = currentTips[0];
  const isFavorite = userFavorites.some(fav => fav.tipId === tip.id);
  
  return `
    <div class="glass-effect-dark rounded-2xl p-8 shadow-2xl relative overflow-hidden animate-fadeIn">
      <div class="absolute top-4 right-4 flex gap-2">
        <button
          class="btn btn-ghost w-10 h-10 bg-white/20 hover:bg-white/30 rounded-full favorite-btn"
          data-tip-id="${tip.id}"
          title="Add to favorites"
        >
          <i class="${isFavorite ? 'fas text-red-500' : 'far text-gray-600'} fa-heart"></i>
        </button>
        <button
          class="btn btn-ghost w-10 h-10 bg-white/20 hover:bg-white/30 rounded-full share-btn"
          data-tip-id="${tip.id}"
          title="Share tip"
        >
          <i class="fas fa-share text-gray-600"></i>
        </button>
      </div>
      
      <div class="mb-4">
        <span class="px-3 py-1 border rounded-full text-sm font-medium ${getCategoryClass(tip.category)}">
          <i class="${getCategoryIcon(tip.category)} mr-1"></i>
          ${tip.category.charAt(0).toUpperCase() + tip.category.slice(1)}
        </span>
      </div>
      
      <div class="mb-6">
        <h2 class="text-2xl lg:text-3xl font-bold text-gray-800 mb-4 leading-relaxed">
          ${tip.title}
        </h2>
        <p class="text-lg text-gray-700 leading-relaxed">
          ${tip.content}
        </p>
      </div>
      
      <div class="flex items-center justify-between">
        <div class="flex items-center gap-4">
          <button
            class="btn btn-primary mark-read-btn"
            data-tip-id="${tip.id}"
          >
            <i class="fas fa-check mr-2"></i>
            Mark as Read
          </button>
        </div>
        <div class="text-sm text-gray-500">
          <i class="fas fa-clock mr-1"></i>
          ${tip.readTime}
        </div>
      </div>
    </div>
  `;
}

function renderTipsList() {
  const moreTips = currentTips.slice(1, 4);
  
  if (moreTips.length === 0) {
    return `
      <div class="space-y-4">
        <h3 class="text-xl font-bold text-white mb-4">More Tips</h3>
        <div class="glass-effect rounded-xl p-8 text-center">
          <i class="fas fa-search text-4xl text-gray-400 mb-4"></i>
          <p class="text-gray-600">No tips found matching your criteria.</p>
        </div>
      </div>
    `;
  }

  return `
    <div class="space-y-4">
      <h3 class="text-xl font-bold text-white mb-4">More Tips</h3>
      ${moreTips.map(tip => {
        const isFavorite = userFavorites.some(fav => fav.tipId === tip.id);
        return `
          <div class="glass-effect rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow duration-300 animate-fadeIn">
            <div class="flex items-start justify-between gap-4">
              <div class="flex-1">
                <div class="flex items-center gap-2 mb-2">
                  <span class="px-2 py-1 border rounded-full text-xs font-medium ${getCategoryClass(tip.category)}">
                    <i class="${getCategoryIcon(tip.category)} mr-1"></i>
                    ${tip.category.charAt(0).toUpperCase() + tip.category.slice(1)}
                  </span>
                  <span class="text-xs text-gray-500">${tip.readTime}</span>
                </div>
                <h4 class="font-semibold text-gray-800 mb-2">${tip.title}</h4>
                <p class="text-gray-600 text-sm">${tip.content.substring(0, 100)}...</p>
              </div>
              <div class="flex flex-col gap-2">
                <button
                  class="btn btn-ghost w-8 h-8 bg-white/50 hover:bg-white/70 rounded-lg favorite-btn"
                  data-tip-id="${tip.id}"
                  title="Add to favorites"
                >
                  <i class="${isFavorite ? 'fas text-red-500' : 'far text-gray-600'} fa-heart text-sm"></i>
                </button>
                <button
                  class="btn btn-ghost w-8 h-8 bg-white/50 hover:bg-white/70 rounded-lg share-btn"
                  data-tip-id="${tip.id}"
                  title="Share"
                >
                  <i class="fas fa-share text-gray-600 text-sm"></i>
                </button>
              </div>
            </div>
          </div>
        `;
      }).join('')}
    </div>
  `;
}

function renderSidebar() {
  const favoriteTips = userFavorites.slice(0, 3).map(fav => {
    const tip = allTips.find(t => t.id === fav.tipId);
    return { ...fav, tip };
  });

  return `
    <div class="space-y-6">
      <!-- Daily Challenge -->
      <div class="glass-effect rounded-2xl p-6 shadow-xl">
        <div class="flex items-center gap-3 mb-4">
          <div class="w-10 h-10 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-lg flex items-center justify-center">
            <i class="fas fa-trophy text-yellow-800"></i>
          </div>
          <h3 class="text-lg font-bold text-gray-800">Daily Challenge</h3>
        </div>
        <p class="text-gray-600 mb-4">Try the Pomodoro Technique for your next work session</p>
        <div class="flex items-center justify-between">
          <button class="btn bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-yellow-900">
            Accept Challenge
          </button>
          <span class="text-xs text-gray-500">4h left</span>
        </div>
      </div>

      <!-- Weekly Progress -->
      <div class="glass-effect rounded-2xl p-6 shadow-xl">
        <h3 class="text-lg font-bold text-gray-800 mb-4">This Week</h3>
        <div class="space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-sm text-gray-600">Tips Read</span>
            <span class="font-semibold text-gray-800">${userStats.weeklyTipsRead}/15</span>
          </div>
          <div class="w-full bg-gray-200 rounded-full h-2">
            <div 
              class="bg-gradient-to-r from-blue-500 to-purple-600 h-2 rounded-full transition-all duration-500" 
              style="width: ${Math.min((userStats.weeklyTipsRead / 15) * 100, 100)}%"
            ></div>
          </div>
          
          <div class="flex items-center justify-between">
            <span class="text-sm text-gray-600">Challenges</span>
            <span class="font-semibold text-gray-800">${userStats.weeklyChallenges}/5</span>
          </div>
          <div class="w-full bg-gray-200 rounded-full h-2">
            <div 
              class="bg-gradient-to-r from-green-400 to-teal-500 h-2 rounded-full transition-all duration-500" 
              style="width: ${Math.min((userStats.weeklyChallenges / 5) * 100, 100)}%"
            ></div>
          </div>
        </div>
      </div>

      <!-- Favorites -->
      <div class="glass-effect rounded-2xl p-6 shadow-xl">
        <div class="flex items-center justify-between mb-4">
          <h3 class="text-lg font-bold text-gray-800">Favorites</h3>
          <button class="btn btn-ghost text-blue-500 hover:text-blue-600 text-sm font-medium">
            View All
          </button>
        </div>
        <div class="space-y-3">
          ${favoriteTips.length > 0 ? favoriteTips.map(favorite => `
            <div class="p-3 bg-white/50 rounded-lg hover:bg-white/70 transition-colors cursor-pointer">
              <div class="flex items-start gap-2">
                <i class="fas fa-heart text-red-500 mt-1 text-sm"></i>
                <div class="flex-1">
                  <p class="text-sm font-medium text-gray-800">${favorite.tip?.title || 'Unknown Tip'}</p>
                  <p class="text-xs text-gray-600">
                    ${favorite.tip?.category ? favorite.tip.category.charAt(0).toUpperCase() + favorite.tip.category.slice(1) + ' • ' : ''}
                    ${new Date(favorite.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </div>
            </div>
          `).join('') : '<p class="text-gray-500 text-sm text-center py-4">No favorites yet</p>'}
        </div>
      </div>

      <!-- Settings -->
      <div class="glass-effect rounded-2xl p-6 shadow-xl">
        <h3 class="text-lg font-bold text-gray-800 mb-4">Settings</h3>
        <div class="space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-sm text-gray-600">Daily Notifications</span>
            <label class="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" ${userSettings.notifications ? 'checked' : ''} class="sr-only peer" id="notifications">
              <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>
          
          <div class="flex items-center justify-between">
            <span class="text-sm text-gray-600">Auto-mark as Read</span>
            <label class="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" ${userSettings.autoMarkRead ? 'checked' : ''} class="sr-only peer" id="autoMarkRead">
              <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>
          
          <button
            class="btn btn-outline w-full bg-white/50 hover:bg-white/70 text-gray-700 text-sm export-btn"
          >
            <i class="fas fa-download mr-2"></i>
            Export My Data
          </button>
        </div>
      </div>
    </div>
  `;
}

function renderShareModal() {
  return `
    <div id="shareModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
      <div class="glass-effect-dark border-none shadow-2xl animate-slideUp max-w-md w-full mx-4 rounded-2xl p-6">
        <div class="flex items-center justify-between mb-4">
          <h3 class="text-lg font-bold text-gray-800">Share Tip</h3>
          <button class="btn btn-ghost" id="closeShareModal">
            <i class="fas fa-times"></i>
          </button>
        </div>
        <div class="space-y-3" id="shareModalContent">
          <!-- Share buttons will be inserted here -->
        </div>
      </div>
    </div>
  `;
}

function setupEventListeners() {
  // Search functionality
  const searchInput = document.getElementById('searchInput');
  if (searchInput) {
    searchInput.addEventListener('input', handleSearch);
  }

  // Category filtering
  document.addEventListener('click', function(e) {
    if (e.target.closest('.category-btn')) {
      const category = e.target.closest('.category-btn').dataset.category;
      handleCategoryFilter(category);
    }

    // Favorite toggle
    if (e.target.closest('.favorite-btn')) {
      const tipId = e.target.closest('.favorite-btn').dataset.tipId;
      toggleFavorite(tipId);
    }

    // Share tip
    if (e.target.closest('.share-btn')) {
      const tipId = e.target.closest('.share-btn').dataset.tipId;
      openShareModal(tipId);
    }

    // Mark as read
    if (e.target.closest('.mark-read-btn')) {
      const tipId = e.target.closest('.mark-read-btn').dataset.tipId;
      markAsRead(tipId);
    }

    // Export data
    if (e.target.closest('.export-btn')) {
      exportData();
    }

    // Close share modal
    if (e.target.closest('#closeShareModal') || (e.target.id === 'shareModal' && !e.target.closest('.glass-effect-dark'))) {
      closeShareModal();
    }
  });

  // Settings toggles
  document.addEventListener('change', function(e) {
    if (e.target.id === 'notifications') {
      userSettings.notifications = e.target.checked;
      saveUserData();
    }
    if (e.target.id === 'autoMarkRead') {
      userSettings.autoMarkRead = e.target.checked;
      saveUserData();
    }
  });
}

function handleSearch(e) {
  const query = e.target.value.toLowerCase();
  if (query === '') {
    currentTips = [...allTips];
  } else {
    currentTips = allTips.filter(tip => 
      tip.title.toLowerCase().includes(query) ||
      tip.content.toLowerCase().includes(query) ||
      tip.category.toLowerCase().includes(query)
    );
  }
  updateTipsDisplay();
}

function handleCategoryFilter(category) {
  // Update button states
  document.querySelectorAll('.category-btn').forEach(btn => {
    btn.classList.remove('ring-2', 'ring-offset-2');
  });
  document.querySelector(`[data-category="${category}"]`).classList.add('ring-2', 'ring-offset-2');

  // Filter tips
  if (category === 'all') {
    currentTips = [...allTips];
  } else {
    currentTips = allTips.filter(tip => tip.category === category);
  }
  updateTipsDisplay();
}

function updateTipsDisplay() {
  const container = document.querySelector('.lg\\:col-span-2');
  if (container) {
    container.innerHTML = `
      ${renderSearchFilters()}
      ${renderFeaturedTip()}
      ${renderTipsList()}
    `;
    // Re-attach event listeners for new elements
    setupEventListeners();
  }
}

function toggleFavorite(tipId) {
  const existingIndex = userFavorites.findIndex(fav => fav.tipId === tipId);
  
  if (existingIndex >= 0) {
    userFavorites.splice(existingIndex, 1);
    userStats.favorites = Math.max(0, userStats.favorites - 1);
  } else {
    userFavorites.push({
      id: Math.random().toString(36).substr(2, 9),
      tipId: tipId,
      userId: currentUserId,
      createdAt: new Date().toISOString()
    });
    userStats.favorites += 1;
  }
  
  saveUserData();
  renderApp();
}

function markAsRead(tipId) {
  userStats.tipsRead += 1;
  userStats.weeklyTipsRead += 1;
  saveUserData();
  renderApp();
}

function openShareModal(tipId) {
  const tip = allTips.find(t => t.id === tipId);
  if (!tip) return;

  const shareUrl = `${window.location.origin}/?tip=${tip.id}`;
  const shareText = `Check out this productivity tip: "${tip.title}" - ${tip.content.substring(0, 100)}...`;

  const modalContent = document.getElementById('shareModalContent');
  modalContent.innerHTML = `
    <button
      class="btn btn-outline w-full flex items-center gap-3 p-3 bg-blue-500/10 hover:bg-blue-500/20 text-gray-700 justify-start"
      onclick="shareOnTwitter('${encodeURIComponent(shareText)}', '${encodeURIComponent(shareUrl)}')"
    >
      <i class="fab fa-twitter text-blue-500"></i>
      <span>Share on Twitter</span>
    </button>
    <button
      class="btn btn-outline w-full flex items-center gap-3 p-3 bg-blue-600/10 hover:bg-blue-600/20 text-gray-700 justify-start"
      onclick="shareOnLinkedIn('${encodeURIComponent(shareUrl)}')"
    >
      <i class="fab fa-linkedin text-blue-600"></i>
      <span>Share on LinkedIn</span>
    </button>
    <button
      class="btn btn-outline w-full flex items-center gap-3 p-3 bg-gray-500/10 hover:bg-gray-500/20 text-gray-700 justify-start"
      onclick="copyToClipboard('${shareUrl}')"
    >
      <i class="fas fa-link text-gray-500"></i>
      <span>Copy Link</span>
    </button>
  `;

  document.getElementById('shareModal').classList.remove('hidden');
}

function closeShareModal() {
  document.getElementById('shareModal').classList.add('hidden');
}

function shareOnTwitter(text, url) {
  const twitterUrl = `https://twitter.com/intent/tweet?text=${text}&url=${url}`;
  window.open(twitterUrl, '_blank');
  closeShareModal();
}

function shareOnLinkedIn(url) {
  const linkedInUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${url}`;
  window.open(linkedInUrl, '_blank');
  closeShareModal();
}

function copyToClipboard(text) {
  navigator.clipboard.writeText(text).then(() => {
    alert('Link copied to clipboard!');
    closeShareModal();
  }).catch(() => {
    alert('Failed to copy link to clipboard.');
  });
}

function exportData() {
  const data = {
    userStats,
    userFavorites,
    userSettings,
    exportDate: new Date().toISOString(),
  };
  
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'productivity-hub-data.json';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);

  alert('Data exported successfully!');
}

function getCategoryIcon(category) {
  const icons = {
    focus: 'fas fa-bullseye',
    wellness: 'fas fa-heart',
    time: 'fas fa-clock',
    organization: 'fas fa-sitemap',
    motivation: 'fas fa-rocket',
  };
  return icons[category] || 'fas fa-lightbulb';
}

function getCategoryClass(category) {
  const classes = {
    focus: 'category-focus',
    wellness: 'category-wellness',
    time: 'category-time',
    organization: 'category-organization',
    motivation: 'category-motivation',
  };
  return classes[category] || 'bg-gray-100/50';
}