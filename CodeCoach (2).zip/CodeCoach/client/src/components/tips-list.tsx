import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import type { Tip } from "@shared/schema";

interface TipsListProps {
  tips: Tip[];
  onToggleFavorite: (tip: Tip) => void;
  onShare: (tip: Tip) => void;
  isTipFavorite: (tipId: string) => boolean;
  isLoading: boolean;
}

const getCategoryIcon = (category: string) => {
  const icons: Record<string, string> = {
    focus: "fas fa-bullseye",
    wellness: "fas fa-heart",
    time: "fas fa-clock",
    organization: "fas fa-sitemap",
    motivation: "fas fa-rocket",
  };
  return icons[category] || "fas fa-lightbulb";
};

const getCategoryClass = (category: string) => {
  const classes: Record<string, string> = {
    focus: "category-focus",
    wellness: "category-wellness",
    time: "category-time",
    organization: "category-organization",
    motivation: "category-motivation",
  };
  return classes[category] || "bg-gray-100/50";
};

export default function TipsList({ tips, onToggleFavorite, onShare, isTipFavorite, isLoading }: TipsListProps) {
  if (isLoading) {
    return (
      <div className="space-y-4">
        <h3 className="text-xl font-bold text-white mb-4">More Tips</h3>
        {[1, 2, 3].map((i) => (
          <div key={i} className="glass-effect rounded-xl p-6 shadow-lg">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1 space-y-2">
                <Skeleton className="h-4 w-20 bg-gray-200" />
                <Skeleton className="h-5 w-3/4 bg-gray-200" />
                <Skeleton className="h-4 w-full bg-gray-200" />
              </div>
              <div className="flex flex-col gap-2">
                <Skeleton className="w-8 h-8 rounded-lg bg-gray-200" />
                <Skeleton className="w-8 h-8 rounded-lg bg-gray-200" />
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (tips.length === 0) {
    return (
      <div className="space-y-4">
        <h3 className="text-xl font-bold text-white mb-4">More Tips</h3>
        <div className="glass-effect rounded-xl p-8 text-center">
          <i className="fas fa-search text-4xl text-gray-400 mb-4"></i>
          <p className="text-gray-600">No tips found matching your criteria.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h3 className="text-xl font-bold text-white mb-4">More Tips</h3>
      
      {tips.map((tip) => (
        <div key={tip.id} className="glass-effect rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow duration-300 animate-fadeIn">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <span className={`px-2 py-1 border rounded-full text-xs font-medium ${getCategoryClass(tip.category)}`}>
                  <i className={`${getCategoryIcon(tip.category)} mr-1`}></i>
                  {tip.category.charAt(0).toUpperCase() + tip.category.slice(1)}
                </span>
                <span className="text-xs text-gray-500">{tip.readTime}</span>
              </div>
              <h4 className="font-semibold text-gray-800 mb-2">{tip.title}</h4>
              <p className="text-gray-600 text-sm line-clamp-2">{tip.content}</p>
            </div>
            <div className="flex flex-col gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => onToggleFavorite(tip)}
                className="w-8 h-8 bg-white/50 hover:bg-white/70 rounded-lg"
                title="Add to favorites"
              >
                <i className={`${isTipFavorite(tip.id) ? 'fas text-red-500' : 'far text-gray-600'} fa-heart text-sm`}></i>
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => onShare(tip)}
                className="w-8 h-8 bg-white/50 hover:bg-white/70 rounded-lg"
                title="Share"
              >
                <i className="fas fa-share text-gray-600 text-sm"></i>
              </Button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
